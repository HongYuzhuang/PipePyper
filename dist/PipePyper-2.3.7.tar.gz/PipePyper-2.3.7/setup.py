# -*- coding: utf-8 -*- 
""" 
Created on 2017-12-08 17:54:20.019635 

@author: 洪宇庄
"""

from setuptools import setup, find_packages

setup(
  	name="PipePyper",
  	version="2.3.7",
  	description="multiThreading calculation FrameWork",
  	author="pyEric",
  	author_email="hongyz1993@163.com",
    packages = find_packages(), 
    url = 'https://github.com/HongYuzhuang/PipePyper'
)

